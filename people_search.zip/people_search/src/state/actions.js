export const FILTER_USER = 'filter user'
export const SELECT_USER = 'select user'
export const BACK_USER = 'back user'

export const filterUserState = (payload) => {
  return {type: FILTER_USER, payload}
};

export const selectUserState = (payload) => {
  return {type: SELECT_USER, payload}
};

export const backUserState = () => {
  return {type: BACK_USER}
}