import { FILTER_USER, SELECT_USER, BACK_USER } from './actions'

class User{
  constructor(
    name,
    city,
    industry,
    hobbies,
    email)
  {
    this.name = name;
    this.city = city;
    this.industry = industry;
    this.hobbies = hobbies;
    this.email = email;
    this.id = genId(this.email, this.industry, this.city);
  }
}

const genId = (str1, str2, str3) => {
  const megaStr = '' + str1 + str2 + str3;
  const chars = [];
  for(let i = 0; i < megaStr.length; i++) {
    const randomVal = Math.floor(Math.random() * 3 * megaStr.charCodeAt(i));
    if (randomVal % 3 === 0) {
      chars.push(i);
    } else {
      chars.push(String.fromCharCode(randomVal));
    }
    if(i === str1.length || i === str2.length) chars.push('-')
  }
  return chars.join('');
}

const initialState = {
  // Testing DisplaySearch and DisplayResults
  stateUserPage: 'user_list_page',
  stateUsers: [
    new User('Bobby', 'Los Angeles', 'Software Development', 'Many many awesome fun hobbies', 'email@email.com'),
    new User('Henry', 'Seattle', 'Software Production', 'TV shows', 'root@email.com'),
    new User('Sofie', 'Boulder', 'Software Engineer', 'Gardening', 'souped up@email.com'),
    new User('Miranda', 'Detroit', 'Mechanic', 'Video Games', 'trippers@email.com'),
    new User('Jerome', 'NYC', 'Physicist', 'Reading', 'email@mailamail.com'),
    new User('Millie', 'Hawkins, Indiana', 'ESP', 'Blowing up things from the upside down', 'hoppin@email.com'),
    new User('Train', 'Oaklahoma City', 'Real Engineer', 'choo choo', 'chooc.choo@email.com'),
  ],
  stateSelectedUser: ''
}

function reducer(state=initialState, action) {
  switch(action.type) {
    case FILTER_USER:
      // filter with action.payload which is e.target.value
      //reducedUsers = reducedUsers.slice(0,2)
      let reducedUsers = []
      initialState.stateUsers.forEach( (element) => {
        if(element.name.toLowerCase().includes(action.payload.toLowerCase())){
          reducedUsers.push(element)
        }else if(action.payload.toLowerCase() === ''){
          reducedUsers = initialState.stateUsers
        }
      })
      return {...state, stateUsers: reducedUsers, stateSelectedUser: '', stateUserPage: 'user_list_page'}
    case SELECT_USER:
      return {...state, stateSelectedUser: action.payload, stateUserPage: 'user_info_page'}
    case BACK_USER:
      return {...state, stateUsers: initialState.stateUsers, stateSelectedUser: '', stateUserPage: 'user_list_page'}
    default:
      return state;
  }
}

export default reducer;