import React, { Component } from 'react';
// import logo from './logo.svg';
import './App.css';
import './ui-toolkit/css/nm-cx/main.css';

import { connect } from 'react-redux'
import { filterUserState, selectUserState, backUserState } from './state/actions';

class App extends Component {
  constructor(props) {
    super(props)

    this.state = {
      appUsers: '',
      appSelectedUser: '',
      appUserPage: ''
    }
    this.displayResults = this.displayResults.bind(this)
    this.displaySearch = this.displaySearch.bind(this)
    this.filterSearch = this.filterSearch.bind(this)
  }

  filterSearch(e) {
    this.props.filterUser(e.target.value.trim())
  }

  displaySearch(props) {
    return (
      <div className="main_app center flexCol">
        <input onChange={this.filterSearch} type="text" placeholder="filter list" />
        <div className="div_borders list upper_left flexCol">
          {props.userinfo.map((x, idx) => {
            return (
              <span className="spanusers div_borders"
                key={'user' + idx}
                onClick={() => { this.props.selectUser(idx) }}>
                {x.name}
              </span>)
          })}
        </div>
      </div>
    )
  }

  displayResults(props) {
    let localuser = props.userinfo
    return (
      <div className="flexCol">
        {/* keyword "this" is referencing the App class this.props, displayResults is just props */}
        <h2 className="center_back"><a onClick={() => { this.props.backUser() }}>Back</a></h2>
        <h1>{localuser.name}</h1>
        <h3>City: {localuser.city}</h3>,
          <h3>Industry: {localuser.industry}</h3>,
          <h3>Hobbies: {localuser.hobbies}</h3>,
          <h3>Email: {localuser.email}</h3>
      </div>
    )
  }

  render() {
    return (
      this.props.appUserPage === "user_info_page" ?
        this.displayResults({ userinfo: this.props.appUsers[this.props.appSelectedUser] }) :
        this.displaySearch({ userinfo: this.props.appUsers }))
  }
}

const getStateFromReduxPassToAppComponentAsProps = (state) => {
  return {
    appUsers: state.stateUsers,
    appSelectedUser: state.stateSelectedUser,
    appUserPage: state.stateUserPage
  }
}

const getDispatchFromReduxToAppComponentAsProps = (dispatch) => {
  return {
    filterUser(filteredUser) {
      dispatch(filterUserState(filteredUser))
    },
    selectUser(selectedUser) {
      dispatch(selectUserState(selectedUser))
    },
    backUser() {
      dispatch(backUserState())
    }
  }
}

export default connect(getStateFromReduxPassToAppComponentAsProps, getDispatchFromReduxToAppComponentAsProps)(App)
