UI-TOOLKIT ASSETS - v1.18.5
-----------------

This package contains built UI-Toolkit assets for version v1.18.5.

For further info, please visit http://uitk.learvest.com/explorer.